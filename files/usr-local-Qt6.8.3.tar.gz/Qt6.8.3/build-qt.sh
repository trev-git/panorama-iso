#!/bin/bash
#
# Please read the instructions before building Qt from source code:
#     https://doc.qt.io/qt-6/linux-building.html
#     https://doc.qt.io/qt-6/linux-requirements.html
#     https://doc.qt.io/qt-6/configure-options.html
#
# First of all, download and unpack the Qt source all-in-one archive to the WORK_DIR (see below)
# for example, download from here:
#     https://qt-mirror.dannhauer.de/official_releases/qt/
#

WORK_DIR=$HOME/work
QT_VERSION=6.8.3
QT_SOURCE=${WORK_DIR}/qt-everywhere-src-${QT_VERSION}
QT_BUILD=${WORK_DIR}/build-qt-${QT_VERSION}
QT_INSTALL=/usr/local/Qt${QT_VERSION}

export PATH=${QT_BUILD}/qtbase/bin:${QT_BUILD}/qtbase/libexec:$PATH
export LD_LIBRARY_PATH=${QT_BUILD}/qtbase/lib:$LD_LIBRARY_PATH
#export PATH=/usr/lib/qt6:/usr/lib/qt6/bin:$PATH

mkdir -p ${QT_BUILD}
cd ${QT_BUILD}
${QT_SOURCE}/configure \
 -prefix ${QT_INSTALL} \
 -disable-rpath \
 -no-pch \
 -no-sbom \
 -optimize-size \
 -release \
 -opensource \
 -confirm-license \
 -nomake tests \
 -nomake examples \
 -opengl es2 \
 -opengles3 \
 -egl \
 -qt-libjpeg \
 -qt-libpng \
 -qt-zlib \
 -skip qtactiveqt \
 -skip qtcharts \
 -skip qtcoap \
 -skip qtconnectivity \
 -skip qtdatavis3d \
 -skip qtdoc \
 -skip qtgraphs \
 -skip qtgrpc \
 -skip qthttpserver \
 -skip qtlanguageserver \
 -skip qtlocation \
 -skip qtlottie \
 -skip qtmqtt \
 -skip qtnetworkauth \
 -skip qtopcua \
 -skip qtpositioning \
 -skip qtremoteobjects \
 -skip qtscxml \
 -skip qtsensors \
 -skip qtserialbus \
 -skip qtspeech \
 -skip qttools \
 -skip qttranslations \
 -skip qtvirtualkeyboard \
 -skip qtwayland \
 -skip qtwebchannel \
 -skip qtwebengine \
 -skip qtwebsockets \
 -skip qtwebview \
 -no-feature-accessibility \
 -no-feature-vaapi \
 -no-sse2 \
 -no-cups \
 -no-glib \
 -no-icu \
 -no-separate-debug-info \

# -- -DFFMPEG_DIR=/usr
# -- -DPC_FFMPEG_LIBRARY_DIRS=/usr/lib/aarch64-linux-gnu -DPC_FFMPEG_INCLUDE_DIRS=/usr/include/aarch64-linux-gnu

if [ $? -eq 0 ]; then
    read -p "Press Enter to build or ^C to abort"
    cmake --build . --parallel 4
else
    exit 1
fi

#if [ $? -eq 0 ]; then
#    read -p "Press Enter to install or ^C to abort"
#    cmake --install .
#else
#    exit 1
#fi
